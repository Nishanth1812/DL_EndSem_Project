import os
import time
import numpy as np

import torch
import torch.nn as nn
from torch.utils.data._utils.collate import default_collate
# import torch.nn.functional as F

from tokamark.tools.utils import get_device


# ----------------------------------------------------------------------------------------------------------------------
# Default values

DEVICE = get_device()
# print(f"Using device: {device}\n")


# ----------------------------------------------------------------------------------------------------------------------
# COLLATE FUNCTION
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
def model_collate_fn(batch, verbose=False):

    # print('in collate model')
    full_flattened_batch = [
        (
            item["shot_id"],
            item["window_index"],
            [np.nan_to_num(np.array(x), nan=0.0) for x in item["input"] + item["exogenous"]],
            item["y"]
            # [np.nan_to_num(np.array(y), nan=0.0) for y in item["y"]]
        )
        for item in batch
    ]

    if verbose:
        print(
            f"Collating batch of size = {len(batch)} shots to N = {len(full_flattened_batch)}"
        )

    return default_collate(full_flattened_batch) if (len(full_flattened_batch) > 0) else None

# ----------------------------------------------------------------------------------------------------------------------
# CNN LOSS
# ----------------------------------------------------------------------------------------------------------------------

class MultiOutputMSELoss(nn.Module):

    def __init__(self, reduction="mean"):
        super().__init__()
        self.reduction = reduction

    def forward(self, y_preds, y_trues):

        if len(y_preds) != len(y_trues):
            raise ValueError("Mismatch in number of outputs.")

        losses = []
        for i, (yp, yt) in enumerate(zip(y_preds, y_trues)):

            if yp.shape != yt.shape:
                raise ValueError(f"Shape mismatch at output {i}: {yp.shape} vs {yt.shape}")

            mask = ~torch.isnan(yt)

            if mask.sum() == 0:
                # No valid targets → skip or append 0 (depends on your preference)
                continue

            diff = yp[mask] - yt[mask]
            l_ = (diff ** 2)

            if self.reduction == "mean":
                l_ = l_.mean()
            elif self.reduction == "sum":
                l_ = l_.sum()

            losses.append(l_)

        if len(losses) == 0:
            return torch.tensor(0.0, device=y_preds[0].device)

        # print(torch.stack(losses).mean())
        return torch.stack(losses).mean()


# ----------------------------------------------------------------------------------------------------------------------
# TRAINING LOOP
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
def move_batch_to_device(batch, device=DEVICE):
    _, _, x, y = batch
    x = [t.to(device=device, dtype=torch.float32) for t in x]
    y = [t.to(device=device, dtype=torch.float32) for t in y]
    return x, y


# ----------------------------------------------------------------------------------------------------------------------
def train_step(model, batch, optimizer, criterion, device=DEVICE):
    model.train()  # Ensure model is in training mode
    
    x, y = move_batch_to_device(batch, device)

    optimizer.zero_grad(set_to_none=True)

    outputs = model(*x)
    loss = criterion(outputs, y)

    loss.backward()
    optimizer.step()

    return loss.item(), y[0].shape[0]


# ----------------------------------------------------------------------------------------------------------------------
@torch.no_grad()
def validate(model, loader, criterion, device=DEVICE, count_stats=False, return_stats=False):
    model.eval()

    total_loss = 0.0
    total_samples = 0
    
    # Track unique shots if requested
    unique_shots = set() if count_stats else None

    for batch in loader:
        if batch is None:
            continue
        
        # Count unique shots if requested
        if count_stats and unique_shots is not None:
            shot_ids, _, _, _ = batch
            unique_shots.update(shot_ids.cpu().numpy())

        x, y = move_batch_to_device(batch, device)

        outputs = model(*x)
        loss = criterion(outputs, y)

        bs = y[0].shape[0]
        total_loss += loss.item() * bs
        total_samples += bs
    
    avg_loss = total_loss / total_samples
    
    # Return statistics if requested
    if return_stats:
        if count_stats and unique_shots is not None:
            stats = {
                "samples": total_samples,
                "unique_shots": len(unique_shots)
            }
        else:
            stats = None
        return avg_loss, stats
    
    return avg_loss



# ======================================================================================================================
class BatchStepTrainer:

    # ------------------------------------------------------------------------------------------------------------------
    def __init__(
        self,
        model,
        train_loader,
        val_loader,
        lr,
        max_steps,
        patience,  # in epochs (upstream: validations of validate_every steps)
        output_dir,
        device=DEVICE,
        validate_every=100,  # unused: validation now runs once per epoch
        verbose=True,
        max_epochs=100,
    ):
        self.max_epochs = max_epochs
        # wall-clock deadline (epoch seconds) set by run.py: stop at an epoch boundary instead of being killed mid-epoch
        self.deadline = float(os.environ.get("TRAIN_DEADLINE", "inf"))
        self.epoch_t0 = time.time()
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.lr = lr
        self.max_steps = max_steps
        self.patience = patience
        self.output_dir = output_dir
        self.device = device
        self.verbose = verbose
        self.validate_every = validate_every

        os.makedirs(output_dir, exist_ok=True)
        self.history_file = os.path.join(output_dir, "training_history.pt")

        self.history = {
            "step": [],
            "train_loss": [],
            "val_loss": [],
            "lr": [],
        }

        self.optimizer = torch.optim.Adam(
            model.parameters(), lr=lr, weight_decay=1e-4
        )
        self.criterion = MultiOutputMSELoss()

        self.best_val_loss = float("inf")
        self.valid_no_improve = 0
        self.current_step = 0
        self.current_batch_loss = []  # track running train loss
        self.batch_iter = iter(self.train_loader)
        
        # Track statistics for first epoch
        self.first_epoch_stats_printed = False
        self.train_unique_shots = set()
        self.train_sample_count = 0
        self.epoch_count = 0

    # ------------------------------------------------------------------------------------------------------------------
    def _save(self, obj, name):
        """Write via a temp file, so a session killed mid-write never leaves a corrupt checkpoint."""
        path = os.path.join(self.output_dir, name)
        torch.save(obj, path + ".tmp")
        os.replace(path + ".tmp", path)

    # ------------------------------------------------------------------------------------------------------------------
    def _plot_losses(self):
        """Redraw loss_curve.png each epoch, so the picture exists even if the session is killed."""
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        epochs = range(1, len(self.history["val_loss"]) + 1)
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.plot(epochs, self.history["train_loss"], "o-", label="train")
        ax.plot(epochs, self.history["val_loss"], "o-", label="validation")
        ax.set(xlabel="epoch", ylabel="masked MSE (standardised)", yscale="log", title="Training curve")
        ax.grid(alpha=0.3)
        ax.legend()
        fig.tight_layout()
        fig.savefig(os.path.join(self.output_dir, "loss_curve.png"), dpi=120)
        plt.close(fig)

    # ------------------------------------------------------------------------------------------------------------------
    def end_epoch(self) -> bool:
        """Validate after a full pass over the training data; False when training should stop."""
        first = self.epoch_count == 0
        result = validate(self.model, self.val_loader, self.criterion, self.device, count_stats=first, return_stats=first)
        val_loss, val_stats = result if first else (result, None)
        avg_train_loss = sum(self.current_batch_loss) / max(1, len(self.current_batch_loss))
        if first:
            stats = {
                "train_samples": self.train_sample_count,
                "train_unique_shots": len(self.train_unique_shots),
                "val_samples": val_stats["samples"],
                "val_unique_shots": val_stats["unique_shots"],
            }
            torch.save(stats, os.path.join(self.output_dir, "first_epoch_stats.pt"))
            print(f"First epoch: {stats}", flush=True)
        self.epoch_count += 1

        self.history["step"].append(self.current_step)
        self.history["train_loss"].append(avg_train_loss)
        self.history["val_loss"].append(val_loss)
        torch.save(self.history, self.history_file)
        self._plot_losses()
        print(f"=== Epoch {self.epoch_count}/{self.max_epochs} | step {self.current_step} | "
              f"train_loss={avg_train_loss:.4f} | val_loss={val_loss:.4f} | gap={val_loss - avg_train_loss:+.4f}", flush=True)

        weights = getattr(self.model, "module", self.model).state_dict()  # unwrapped: loads into the plain model
        improved = val_loss < self.best_val_loss
        if improved:
            self.best_val_loss = val_loss
            self.valid_no_improve = 0
            self._save(weights, "best_model.pt")
            print(f"    saved best_model.pt (val_loss {val_loss:.4f})", flush=True)
        # full state every epoch, so a run can be inspected or resumed from its last finished epoch
        self._save({"epoch": self.epoch_count, "step": self.current_step, "model": weights,
                    "optimizer": self.optimizer.state_dict(), "best_val_loss": self.best_val_loss,
                    "history": self.history}, "last.pt")
        if not improved:
            self.valid_no_improve += 1
            print(f"    val_loss did not improve ({self.valid_no_improve}/{self.patience}); best {self.best_val_loss:.4f}", flush=True)
            if self.valid_no_improve >= self.patience:
                print(f"Early stopping: no improvement for {self.patience} epochs.", flush=True)
                return False
        epoch_s, self.epoch_t0 = time.time() - self.epoch_t0, time.time()
        if time.time() + epoch_s > self.deadline:
            print(f"Stopping after epoch {self.epoch_count}: another epoch (~{epoch_s / 60:.0f} min) "
                  f"would pass the time budget.", flush=True)
            return False
        return self.epoch_count < self.max_epochs

    # ------------------------------------------------------------------------------------------------------------------
    def step_batch(  # NOSONAR - Ignore cognitive complexity
            self
    ) -> bool:
        """Perform a single batch update. Validate every `validate_every` batches."""
        try:
            batch = next(self.batch_iter)
        except StopIteration:
            # End of epoch: validate once, checkpoint, early-stop (patience counts epochs)
            if not self.end_epoch():
                return False
            self.batch_iter = iter(self.train_loader)
            batch = next(self.batch_iter)
            self.current_batch_loss = []  # reset running loss per epoch

        if batch is None:
            return True  # skip empty batch
        
        # Count unique shots and samples in first epoch
        if self.epoch_count == 0:
            shot_ids, _, _, _ = batch
            self.train_unique_shots.update(shot_ids.cpu().numpy())

        # ---- Train step ----
        loss, bs = train_step(
            self.model,
            batch,
            self.optimizer,
            self.criterion,
            self.device,
        )
        
        # Count samples in first epoch
        if self.epoch_count == 0:
            self.train_sample_count += bs
        
        self.current_batch_loss.append(loss)
        self.current_step += 1

        # ---- Average train loss so far in this step/epoch ----
        avg_train_loss = sum(self.current_batch_loss) / len(self.current_batch_loss)

        # ---- Progress only (validation runs once per epoch, see end_epoch) ----
        if self.verbose and self.current_step % 100 == 0:
            print(f"Epoch {self.epoch_count + 1} | step {self.current_step} | train_loss={avg_train_loss:.4f}", flush=True)

        # ---- Stop if max steps reached ----
        if self.current_step >= self.max_steps:
            if self.verbose:
                print(f"Max steps {self.max_steps} reached.")
            return False

        return True
