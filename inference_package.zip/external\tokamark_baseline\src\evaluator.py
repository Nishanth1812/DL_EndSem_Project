import os
import torch

import numpy as np
import matplotlib.pyplot as plt

from tokamark.tasks import get_task_metadata
from tokamark.tools.utils import get_device


# ----------------------------------------------------------------------------------------------------------------------

# Set device
device = get_device()


# ----------------------------------------------------------------------------------------------------------------------
# CNN EVALUATION LOOP
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
def cnn_unstd_evaluation_per_shot(
    test_dataloader,
    config_task,
    cnn_model,
    output_dir,
    accumulator
):
    """Evaluate CNN per shot/window and save incremental RMSEs to CSV."""

    print("in cnn_unstd_evaluation_per_shot")

    best_model_path = output_dir + "best_model.pt"

    # Load best model
    cnn_model.load_state_dict(torch.load(best_model_path, map_location=device))
    cnn_model.to(device)
    cnn_model.eval()

    feature_names = config_task["sources_and_signals"].get("output_name", [])
    
    dict_task_metadata = get_task_metadata(
        config_task,
        verbose=False
    )

    # === Evaluation loop ===
    last = None
    with torch.no_grad():
        for batch_idx, batch in enumerate(test_dataloader):
            if batch is None:
                continue

            shot_id, window_id, x_test, y_test = batch
            if batch_idx % 20 == 0:  # evaluation is otherwise silent until it finishes
                print(f"eval batch {batch_idx}", flush=True)

            # Move inputs and labels to device
            x_test = [arr.to(torch.float32).to(device) for arr in x_test]
            y_test = [arr.to(torch.float32).to(device) for arr in y_test]

            # Model prediction
            y_pred = cnn_model(*x_test)

            # Make sure y_pred is list-like
            if not isinstance(y_pred, (list, tuple)):
                y_pred = [y_pred]

            for i, feature_name in enumerate(feature_names):

                y_t = (
                    y_test[i]
                    .detach()
                    .cpu()
                    .squeeze(1)
                    .reshape(len(shot_id), -1)
                    .numpy()
                )
                y_p = (
                    y_pred[i]
                    .detach()
                    .cpu()
                    .squeeze(1)
                    .reshape(len(shot_id), -1)
                    .numpy()
                )

                mean = dict_task_metadata['output'][f"{feature_name[0]}-{feature_name[1]}"]['mean']
                std = dict_task_metadata['output'][f"{feature_name[0]}-{feature_name[1]}"]['std']

                unstd_y_t = y_t*std + mean
                unstd_y_p = y_p*std + mean 

                accumulator.add_batch(
                    y_target=np.float128(unstd_y_t),
                    y_pred=np.float128(unstd_y_p),
                    shot_ids=shot_id,
                    window_indices=window_id,
                    feature_name=f"{feature_name[0]}-{feature_name[1]}",
                )
                if i == 0:  # last window seen, for prediction.png; the last two dims are the spatial grid
                    grid = y_test[i].shape[-2:]
                    last = (int(shot_id[-1]), int(window_id[-1]), feature_name,
                            unstd_y_t[-1].reshape(-1, *grid)[-1], unstd_y_p[-1].reshape(-1, *grid)[-1])

    print("💅🏼 UNSTD Evaluation done. RMSEs and MSEs saved (incrementally).")
    if last is not None:
        plot_prediction(*last, os.path.join(output_dir, "prediction.png"))


# ----------------------------------------------------------------------------------------------------------------------
def plot_prediction(shot, window, feature_name, y_true, y_pred, path):
    """True vs predicted map of one test window, plus the error (NaN = masked target)."""
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    lo, hi = np.nanmin(y_true), np.nanmax(y_true)
    err = y_pred - y_true
    lim = np.nanmax(np.abs(err))
    for ax, img, title, kw in (
        (axes[0], y_true, "true", dict(vmin=lo, vmax=hi)),
        (axes[1], y_pred, "predicted", dict(vmin=lo, vmax=hi)),
        (axes[2], err, f"error (RMSE {np.sqrt(np.nanmean(err ** 2)):.3g})", dict(cmap="RdBu_r", vmin=-lim, vmax=lim)),
    ):
        fig.colorbar(ax.imshow(img, origin="lower", **kw), ax=ax)
        ax.set_title(title)
    fig.suptitle(f"{feature_name[0]}/{feature_name[1]}: shot {shot}, window {window} (last test window)")
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    print(f"saved {path}", flush=True)